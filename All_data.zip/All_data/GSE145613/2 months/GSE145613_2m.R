

    library(edgeR)
    library(DGEobj.utils)
    
    expr_data <- read.table("GSE145613_2m.txt", header = TRUE, row.names = 1, sep = "")
    expr_data <- as.matrix(expr_data)
    head(expr_data)
    dim(expr_data)
    
    Group <- read.csv("GSE145613_2m_group.csv", header=T, sep=",")
    head(data)
    dim(data)
    
    cpm <- convertCounts(
      expr_data,
      unit = "cpm",
      log = FALSE,
      normalize = "none"
    )
    data_edgeR <- round(cpm)
    group_edgeR <- Group$Group
    data_edgeR[data_edgeR==0] <- NA
    data_edgeR<-data_edgeR[complete.cases(data_edgeR),]
    d <- DGEList(counts = data_edgeR, group = group_edgeR)
    class(d)
    counts <- d$counts
    samples <- d$samples
    
    keep <- filterByExpr(d)
    table(keep)
    d <- d[keep,,keep.lib.sizes=FALSE]
    
    d <- calcNormFactors(d, method="TMM")
    head(d$samples)
    
    plotMDS(d)
    
    design_edgeR <-model.matrix(~0+factor(group_edgeR))
    colnames(design_edgeR) <- levels(factor(group_edgeR))
    rownames(design_edgeR) <- colnames(expr_data)
    
    d <- estimateDisp(d, design_edgeR, robust=TRUE)
    fit <- glmQLFit(d, design_edgeR, robust=TRUE)
    
    contrast <- makeContrasts(SCA3-WT, levels=design_edgeR)
    res <- glmQLFTest(fit, contrast = contrast)
    
    res$table$qvalue <- p.adjust(res$table$PValue, method = "BH")
    DEG_edgeR <- as.data.frame(res)
    
    DEG_edgeR$regulate <- ifelse(DEG_edgeR$qvalue > 0.1, "unchanged",
                                 ifelse(DEG_edgeR$logFC > 1, "up-regulated",
                                        ifelse(DEG_edgeR$logFC < -1,"down-regulated","unchanged")))
    table(DEG_edgeR$regulate)
    
    library(DESeq2)
    data_Deseq <- data_edgeR
    group_Deseq <- factor(c(rep("WT", times=5),rep("SCA3", times=5)))
    Data <- data.frame(row.names = colnames(data_Deseq), group = group_Deseq)
    dds <- DESeqDataSetFromMatrix(countData = data_Deseq, colData = Data, design = ~ group)
    
    dds <- DESeq(dds)
    res <- results(dds, contrast = c("group","SCA3","WT"), alpha=0.05, pAdjustMethod="BH")
    DEG_Deseq <- as.data.frame(res)
    DEG_Deseq <- na.omit(DEG_Deseq)
    colnames(DEG_Deseq)
    DEG_Deseq$regulate <- ifelse(DEG_Deseq$padj > 0.05, "unchanged",
                                 ifelse(DEG_Deseq$log2FoldChange > 1, "up-regulated",
                                        ifelse(DEG_Deseq$log2FoldChange < -1,"down-regulated","unchanged")))
    table(DEG_Deseq$regulate)
    
    library(limma)
    
    data_limma <- data_edgeR
    group_limma <- Group
    
    design_limma <-model.matrix(~0+factor(group_limma$Group))
    colnames(design_limma) <- levels(factor(group_limma$Group))
    rownames(design_limma) <- colnames(data_limma)
    contrast.matrix <- makeContrasts(SCA3-WT, levels=design_limma)
    fit_limma <- lmFit(data_limma, design_limma)
    fit <- contrasts.fit(fit_limma, contrast.matrix)
    fit <- eBayes(fit)
    DEG_limma <- topTable(fit, coef=1, n=Inf)
    DEG_limma$regulate <- ifelse(DEG_limma$adj.P.Val > 0.05, "unchanged",
                                 ifelse(DEG_limma$logFC > 1, "up-regulated",
                                        ifelse(DEG_limma$logFC < -1,"down-regulated","unchanged")))
    table(DEG_limma$regulate)
    
    library(ggVennDiagram)
    library(VennDiagram)
    table(DEG_edgeR$regulate)
    table(DEG_Deseq$regulate)
    table(DEG_limma$regulate)
    edgeR_deg <- rownames(DEG_edgeR[DEG_edgeR$regulate !="unchanged",])
    Deseq_deg <- rownames(DEG_Deseq[DEG_Deseq$regulate !="unchanged",])
    limma_deg <- rownames(DEG_limma[DEG_limma$regulate !="unchanged",])
    
    list_ID <- list('edgeR'=edgeR_deg, 'DESeq2'=Deseq_deg,'limma'=limma_deg)
    diagram <- ggVennDiagram(list_ID, label_alpha = 0) + scale_fill_gradient(low="white", high ="yellow") 
    ggarrange(diagram)
    
    intersect_all <- Reduce(intersect, list_ID)
    intersect_all
    