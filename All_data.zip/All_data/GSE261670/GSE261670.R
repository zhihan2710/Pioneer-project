if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("tximport")
BiocManager::install("rhdf5")
BiocManager::install("biomaRt")

library(tximport)
library(rhdf5)
base_dir <- "/Users/emma/Desktop/kallisto"
sample_id <- dir(file.path(base_dir))
sample_id
kal_dirs <- sapply(sample_id, function(id) file.path(base_dir, id,"abundance.tsv"))
kal_dirs
setwd("/Users/emma/Desktop/GSE261670")
file_path <- file.path(getwd(), "design_matrix.txt")
s2c <- read.table("./design_matrix.txt", header = TRUE, sep='\t',stringsAsFactors=FALSE)
s2c
s2c <- dplyr::mutate(s2c, path = kal_dirs)
print(s2c)

library(biomaRt)
mart <- biomaRt::useMart(biomart = "ENSEMBL_MART_ENSEMBL",
                         dataset = "mmusculus_gene_ensembl",
                         host = 'https://ensembl.org')
t2g <- biomaRt::getBM(attributes = c("ensembl_transcript_id", "ensembl_gene_id",
                                     "external_gene_name"), mart = mart)
t2g <- dplyr::rename(t2g, target_id = ensembl_transcript_id,
                     ens_gene = ensembl_gene_id, ext_gene = external_gene_name)

info <- txi$abundance

library(expss)
library(openxlsx)
wb = createWorkbook()
sh = addWorksheet(wb, "Tables")
xl_write(info, wb, sh)
saveWorkbook(wb, "info1.xlsx", overwrite = TRUE)

library(DESeq2)
txi<-tximport(files=kal_dirs,type='kallisto',tx2gene=t2g,txOut = TRUE)
dds<-DESeqDataSetFromTximport(txi,s2c,~condition)
dds <- DESeq(dds)
res <- results(dds, contrast = c("condition","SCA3","WT"), alpha=0.05, pAdjustMethod="BH")
DEG_Deseq <- as.data.frame(res)
DEG_Deseq <- na.omit(DEG_Deseq)
colnames(DEG_Deseq)
DEG_Deseq$regulate <- ifelse(DEG_Deseq$padj > 0.005, "unchanged",
                             ifelse(DEG_Deseq$log2FoldChange > 1, "up-regulated",
                                    ifelse(DEG_Deseq$log2FoldChange < -1,"down-regulated","unchanged")))
table(DEG_Deseq$regulate)


library(edgeR)

Group <- read.csv("GSE261670_group.csv", header=T, sep=",")
head(data)
dim(data)
group_edgeR <- Group$Group

cts <- txi$counts
normMat <- txi$length

# Obtaining per-observation scaling factors for length, adjusted to avoid
# changing the magnitude of the counts.
normMat <- normMat/exp(rowMeans(log(normMat)))
normCts <- cts/normMat

# Computing effective library sizes from scaled counts, to account for
# composition biases between samples.
eff.lib <- calcNormFactors(normCts) * colSums(normCts)

# Combining effective library sizes with the length factors, and calculating
# offsets for a log-link GLM.
normMat <- sweep(normMat, 2, eff.lib, "*")
normMat <- log(normMat)

y <- DGEList(cts)
y <- scaleOffset(y, normMat)

design_edgeR <- model.matrix(~0+factor(group_edgeR))
colnames(design_edgeR) <- levels(factor(group_edgeR))
keep <- filterByExpr(y, design)
y <- y[keep, ]

d <- estimateDisp(y, design_edgeR, robust=TRUE)
fit <- glmQLFit(y, design_edgeR, robust=TRUE)

contrast <- makeContrasts(SCA3-WT, levels=design_edgeR)
res <- glmQLFTest(fit, contrast = contrast)

res$table$qvalue <- p.adjust(res$table$PValue, method = "BH")
DEG_edgeR <- as.data.frame(res)

DEG_edgeR$regulate <- ifelse(DEG_edgeR$qvalue > 0.05, "unchanged",
                             ifelse(DEG_edgeR$logFC > 1, "up-regulated",
                                    ifelse(DEG_edgeR$logFC < -1,"down-regulated","unchanged")))
table(DEG_edgeR$regulate)


library(limma)
y <- DGEList(txi$counts)
keep <- filterByExpr(y, design)
y <- y[keep, ]
y <- calcNormFactors(y)
v <- voom(y, design)
design_limma <-model.matrix(~0+factor(group_edgeR))
colnames(design_limma) <- levels(factor(group_edgeR))

contrast.matrix <- makeContrasts(SCA3-WT, levels=design_limma)
fit_limma <- lmFit(v, design_limma)
fit <- contrasts.fit(fit_limma, contrast.matrix)
fit <- eBayes(fit)
DEG_limma <- topTable(fit, coef=1, n=Inf)
DEG_limma$regulate <- ifelse(DEG_limma$adj.P.Val > 0.05, "unchanged",
                             ifelse(DEG_limma$logFC > 1, "up-regulated",
                                    ifelse(DEG_limma$logFC < -1,"down-regulated","unchanged")))
table(DEG_limma$regulate)


library(ggVennDiagram)
library(VennDiagram)
table(DEG_edgeR$regulate)
table(DEG_Deseq$regulate)
table(DEG_limma$regulate)
edgeR_deg <- rownames(DEG_edgeR[DEG_edgeR$regulate !="unchanged",])
Deseq_deg <- rownames(DEG_Deseq[DEG_Deseq$regulate !="unchanged",])
limma_deg <- rownames(DEG_limma[DEG_limma$regulate !="unchanged",])
list_ID <- list('edgeR'=edgeR_deg, 'DESeq2'=Deseq_deg,'limma'=limma_deg)
diagram <- ggVennDiagram(list_ID, label_alpha = 0) + scale_fill_gradient(low="white", high ="yellow") 
ggarrange(diagram)

intersect_all <- Reduce(intersect, list_ID)
intersect_all
