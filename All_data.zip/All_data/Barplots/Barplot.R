library(ggplot2)
library(dplyr)

df <- read.table("barplot GSE107958 brainstem new.txt", header = TRUE)
df$gene <- factor(df$gene, levels = paste0("sample", 1:10))
ggplot(df, aes(x = gene, y = mean)) +
  geom_bar(stat = "identity", width = 0.4) +
  geom_errorbar(aes(ymin = mean - SEM, ymax = mean + SEM), width = 0.2) +
  theme_minimal() +
  labs(x = "Gene", y = "Expression level (CPM)") 

df <- read.table("barplot GSE107958 cerebellum.txt", header = TRUE)
df$gene <- factor(df$gene, levels = paste0("sample", 1:10))
ggplot(df, aes(x = gene, y = mean)) +
  geom_bar(stat = "identity", width = 0.4) +
  geom_errorbar(aes(ymin = mean - SEM, ymax = mean + SEM), width = 0.2) +
  theme_minimal() +
  labs(x = "Gene", y = "Expression level (CPM)") 

df <- read.table("barplot GSE145613 12m.txt", header = TRUE)
df$gene <- factor(df$gene, levels = paste0("sample", 1:16))
ggplot(df, aes(x = gene, y = mean)) +
  geom_bar(stat = "identity", width = 0.4) +
  geom_errorbar(aes(ymin = mean - SEM, ymax = mean + SEM), width = 0.2) +
  theme_minimal() +
  labs(x = "Gene", y = "Expression level (CPM)") 

df <- read.table("barplot GSE145613 12m up.txt", header = TRUE)
df$gene <- factor(df$gene, levels = paste0("sample", 1:4))
ggplot(df, aes(x = gene, y = mean)) +
  geom_bar(stat = "identity", width = 0.4) +
  geom_errorbar(aes(ymin = mean - SEM, ymax = mean + SEM), width = 0.2) +
  theme_minimal() +
  labs(x = "Gene", y = "Expression level (CPM)") 

df <- read.table("barplot GSE145613 12m down.txt", header = TRUE)
df$gene <- factor(df$gene, levels = paste0("sample", 1:4))
ggplot(df, aes(x = gene, y = mean)) +
  geom_bar(stat = "identity", width = 0.4) +
  geom_errorbar(aes(ymin = mean - SEM, ymax = mean + SEM), width = 0.2) +
  theme_minimal() +
  labs(x = "Gene", y = "Expression level (CPM)") 

df <- read.table("barplot GSE261670 up.txt", header = TRUE)
df$gene <- factor(df$gene, levels = paste0("sample", 1:24))
ggplot(df, aes(x = gene, y = mean)) +
  geom_bar(stat = "identity", width = 0.4) +
  geom_errorbar(aes(ymin = mean - SEM, ymax = mean + SEM), width = 0.2) +
  theme_minimal() +
  labs(x = "Gene", y = "Expression level (TPM)") 

df <- read.table("barplot GSE261670 down.txt", header = TRUE)
df$gene <- factor(df$gene, levels = paste0("sample", 1:24))
ggplot(df, aes(x = gene, y = mean)) +
  geom_bar(stat = "identity", width = 0.4) +
  geom_errorbar(aes(ymin = mean - SEM, ymax = mean + SEM), width = 0.2) +
  theme_minimal() +
  labs(x = "Gene", y = "Expression level (TPM)") 
