install.packages("ggVennDiagram")
install.packages("VennDiagram")
BiocManager::install("edgeR")
BiocManager::install("DESeq2")
BiocManager::install("limma", force=TRUE)

library(edgeR)

expr_data <- read.table("GSE107958_brainstem.txt", header = TRUE, row.names = 1, sep = "")
head(expr_data)
dim(expr_data)

Group <- read.csv("GSE107958_brainstem_group.csv", header=T, sep=",")
head(Group)
dim(Group)

data_edgeR <- expr_data
group_edgeR <- Group$Group

d <- DGEList(counts = data_edgeR, group = group_edgeR)
class(d)
counts <- d$counts
samples <- d$samples

keep <- filterByExpr(d)
table(keep)
d <- d[keep,,keep.lib.sizes=FALSE]

d <- calcNormFactors(d, method="TMM")
head(d$samples)

design_edgeR <-model.matrix(~0+factor(group_edgeR))
colnames(design_edgeR) <- levels(factor(group_edgeR))
rownames(design_edgeR) <- colnames(expr_data)

d <- estimateDisp(d, design_edgeR, robust=TRUE)
fit <- glmQLFit(d, design_edgeR, robust=TRUE)

contrast <- makeContrasts(SCA3-WT, levels=design_edgeR)
res <- glmQLFTest(fit, contrast = contrast)
res$table$qvalue <- p.adjust(res$table$PValue, method = "BH")
summary(res$table$logFC) 
summary(res$qvalue) 
DEG_edgeR <- as.data.frame(res)

colnames(DEG_edgeR)
DEG_edgeR$regulate <- ifelse(DEG_edgeR$qvalue > 0.05, "unchanged",
                             ifelse(DEG_edgeR$logFC > 1, "up-regulated",
                                    ifelse(DEG_edgeR$logFC < -1,"down-regulated","unchanged")))
table(DEG_edgeR$regulate)

library(DESeq2)

data_Deseq <- expr_data
group_Deseq <- factor(c(rep("WT", times=8),rep("SCA3", times=6)))
Data <- data.frame(row.names = colnames(data_Deseq), group = group_Deseq)
dds <- DESeqDataSetFromMatrix(countData = data_Deseq, colData = Data, design = ~ group)

dds <- DESeq(dds)
res <- results(dds, contrast = c("group","SCA3","WT"), alpha=0.05, pAdjustMethod="BH")
DEG_Deseq <- as.data.frame(res)
DEG_Deseq <- na.omit(DEG_Deseq)
colnames(DEG_Deseq)
DEG_Deseq$regulate <- ifelse(DEG_Deseq$padj > 0.05, "unchanged",
                             ifelse(DEG_Deseq$log2FoldChange > 1, "up-regulated",
                                    ifelse(DEG_Deseq$log2FoldChange < -1,"down-regulated","unchanged")))
table(DEG_Deseq$regulate)


library(limma)

data_limma <- expr_data
group_limma <- Group

design_limma <-model.matrix(~0+factor(group_limma$Group))
colnames(design_limma) <- levels(factor(group_limma$Group))
rownames(design_limma) <- colnames(data_limma)
contrast.matrix <- makeContrasts(SCA3-WT, levels=design_limma)
fit_limma <- lmFit(data_limma, design_limma)
fit2 <- contrasts.fit(fit_limma, contrast.matrix)
fit2 <- eBayes(fit2)
DEG_limma <- topTable(fit2, coef=1, n=Inf)
DEG_limma$regulate <- ifelse(DEG_limma$adj.P.Val > 0.05, "unchanged",
                             ifelse(DEG_limma$logFC > 1, "up-regulated",
                                    ifelse(DEG_limma$logFC < -1,"down-regulated","unchanged")))
table(DEG_limma$regulate)


library(ggVennDiagram)
library(VennDiagram)
table(DEG_edgeR$regulate)
table(DEG_Deseq$regulate)
table(DEG_limma$regulate)
edgeR_deg <- rownames(DEG_edgeR[DEG_edgeR$regulate !="unchanged",])
Deseq_deg <- rownames(DEG_Deseq[DEG_Deseq$regulate !="unchanged",])
limma_deg <- rownames(DEG_limma[DEG_limma$regulate !="unchanged",])

list_ID <- list('edgeR'=edgeR_deg, 'DESeq2'=Deseq_deg,'limma'=limma_deg)
diagram1 <- ggVennDiagram(list_ID, label_alpha = 0) + scale_fill_gradient(low="white", high ="yellow") 
ggarrange(diagram1)

intersect_all <- Reduce(intersect, list_ID)
intersect_all
